<script setup>
// Props: pokemon (objeto), onAdquirida (función)
defineProps({
  pokemon: Object,
  onAdquirida: Function
})
</script>

<template>
  <div class="flex flex-col items-center p-2 bg-white/80 rounded shadow hover:scale-105 transition-all cursor-pointer">
    <img :src="pokemon.imagen_url" :alt="pokemon.nombre" class="w-16 h-16 object-contain" :class="{'grayscale': !pokemon.adquirida, 'opacity-70': !pokemon.adquirida}" />
    <div class="text-sm font-semibold mt-1">#{{ pokemon.numero }}</div>
    <div class="text-xs text-gray-700">{{ pokemon.nombre }}</div>
    <button v-if="!pokemon.adquirida" @click="onAdquirida(pokemon)" class="mt-1 text-xs bg-green-400 hover:bg-green-500 text-white px-2 py-1 rounded">Adquirida</button>
  </div>
</template>

<style scoped>
.grayscale {
  filter: grayscale(1);
}
</style>
