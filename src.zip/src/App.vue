<script setup>
import { ref, computed, onMounted, onBeforeUnmount } from 'vue'
import { useColeccionStore } from './stores/coleccion.js'
import PokemonCard from './components/PokemonCard.vue'

const buscador = ref('')
const resultadoBusqueda = ref(null)
const buscando = ref(false)
const totalPokemons = 1025

const coleccion = useColeccionStore()

// Filtros
const filtro = ref('todos')
const mostrarFiltros = ref(false)
const filtroRef = ref(null)

function clickFuera(e) {
  if (mostrarFiltros.value && filtroRef.value && !filtroRef.value.contains(e.target)) {
    mostrarFiltros.value = false
  }
}
onMounted(() => {
  document.addEventListener('click', clickFuera)
  coleccion.cargarColeccion()
})
onBeforeUnmount(() => {
  document.removeEventListener('click', clickFuera)
})

const adquiridos = computed(() => coleccion.pokemons.filter(p => p.adquirida))
const porcentaje = computed(() => ((adquiridos.value.length / totalPokemons) * 100).toFixed(1))
const faltantes = computed(() => totalPokemons - adquiridos.value.length)

const pokemonsFiltrados = computed(() => {
  let base = coleccion.pokemons
  if (filtro.value === 'adquiridos') base = base.filter(p => p.adquirida)
  if (filtro.value === 'faltantes') base = base.filter(p => !p.adquirida)
  if (buscador.value) return base.filter(p => p.numero.toString() === buscador.value)
  return base
})

const buscar = () => {
  buscando.value = true
  const poke = coleccion.pokemons.find(p => p.numero.toString() === buscador.value)
  resultadoBusqueda.value = poke || null
  buscando.value = false
}

const marcarAdquirida = async (pokemon) => {
  await coleccion.marcarAdquirida(pokemon)
}
</script>

<template>
  <div class="min-h-screen bg-gradient-to-b from-yellow-100 to-blue-200 flex flex-col items-center py-6">
    <!-- Header -->
    <header class="w-full max-w-2xl mx-auto mb-6">
      <div class="flex flex-col gap-2">
        <h1 class="text-4xl font-bold text-left text-yellow-700 mb-1" style="font-family: 'Fredoka One', 'Comic Sans', cursive;">Mi Colección</h1>
        <div class="flex items-center gap-3">
          <div class="flex-1 h-4 bg-gray-200 rounded-full overflow-hidden relative">
            <div class="h-full bg-green-400" :style="{width: porcentaje + '%'}"></div>
            <span class="absolute right-2 top-0 text-xs font-bold text-gray-700">{{ porcentaje }}%</span>
          </div>
          <div class="ml-2 text-right text-sm font-mono text-gray-700">
            <span class="font-bold text-green-700">{{ adquiridos.length }}</span> /
            <span>{{ totalPokemons }}</span>
          </div>
        </div>
      </div>
    </header>

    <!-- Buscador y Filtros -->
    <div class="w-full max-w-2xl flex gap-3 mb-6">
      <input v-model="buscador" @keyup.enter="buscar" type="number" min="1" max="1025" placeholder="Buscar por número..." class="flex-1 rounded px-3 py-2 border border-gray-300 focus:outline-none focus:ring-2 focus:ring-yellow-400 bg-white/80" />
      <div class="relative" ref="filtroRef">
        <button @click="mostrarFiltros = !mostrarFiltros" class="flex items-center gap-1 px-4 py-2 rounded bg-gray-200 hover:bg-gray-300 text-gray-700 font-semibold shadow">
          Filtros
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor" class="w-4 h-4"><path stroke-linecap="round" stroke-linejoin="round" d="M12 6v6m0 0v6m0-6h6m-6 0H6" /></svg>
        </button>
        <div v-if="mostrarFiltros" class="absolute right-0 mt-2 w-40 bg-white rounded shadow z-10">
          <ul>
            <li :class="{'bg-yellow-100 font-bold': filtro==='todos'}" class="px-4 py-2 hover:bg-yellow-50 cursor-pointer" @click="filtro='todos'; mostrarFiltros=false">Todos</li>
            <li :class="{'bg-yellow-100 font-bold': filtro==='adquiridos'}" class="px-4 py-2 hover:bg-yellow-50 cursor-pointer" @click="filtro='adquiridos'; mostrarFiltros=false">Solo adquiridos</li>
            <li :class="{'bg-yellow-100 font-bold': filtro==='faltantes'}" class="px-4 py-2 hover:bg-yellow-50 cursor-pointer" @click="filtro='faltantes'; mostrarFiltros=false">Solo faltantes</li>
          </ul>
        </div>
      </div>
    </div>

    <!-- Resultado de búsqueda -->
    <div v-if="resultadoBusqueda" class="mb-6 flex flex-col items-center w-full max-w-2xl">
      <div class="flex items-center gap-4 w-full bg-white/80 rounded shadow p-4">
        <img :src="resultadoBusqueda.imagen_url" :alt="resultadoBusqueda.nombre" class="w-24 h-24 object-contain rounded-lg border border-gray-300" :class="{'grayscale': !resultadoBusqueda.adquirida, 'opacity-70': !resultadoBusqueda.adquirida}" />
        <div class="flex-1">
          <div class="text-lg font-semibold">#{{ resultadoBusqueda.numero }} {{ resultadoBusqueda.nombre }}</div>
          <div v-if="resultadoBusqueda.adquirida" class="text-green-600 font-bold">¡La tienes!</div>
          <div v-else class="text-red-500 font-bold">No la tienes</div>
        </div>
        <button v-if="!resultadoBusqueda.adquirida" @click="marcarAdquirida(resultadoBusqueda)" class="ml-4 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded">Adquirida</button>
      </div>
    </div>

    <!-- Cuadrícula de Pokémon -->
    <div class="w-full max-w-2xl grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
      <PokemonCard
        v-for="pokemon in pokemonsFiltrados"
        :key="pokemon.numero"
        :pokemon="pokemon"
        :onAdquirida="marcarAdquirida"
      />
    </div>

    <!-- Loader -->
    <div v-if="coleccion.loading" class="fixed inset-0 bg-black/20 flex items-center justify-center z-50">
      <div class="bg-white p-6 rounded shadow text-lg font-bold text-yellow-600">Cargando colección...</div>
    </div>
  </div>
</template>

<style scoped>
.grayscale {
  filter: grayscale(1);
}
</style>
